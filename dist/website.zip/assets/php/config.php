<?php
	$slack_webhook_endpoint = "https://hooks.slack.com/services/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";
	$recaptcha_secret = "6LdIV8gpAAAAAFup9VlykZrugDYIR_67Mc999kfs";
?>